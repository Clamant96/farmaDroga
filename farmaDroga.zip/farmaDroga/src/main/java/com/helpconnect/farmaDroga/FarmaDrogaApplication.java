package com.helpconnect.farmaDroga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmaDrogaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmaDrogaApplication.class, args);
	}

}
