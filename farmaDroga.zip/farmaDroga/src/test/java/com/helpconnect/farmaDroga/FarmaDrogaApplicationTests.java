package com.helpconnect.farmaDroga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaDrogaApplicationTests {

	@Test
	void contextLoads() {
	}

}
